import { useState } from 'react';
import { INBOX } from './data.js';

export default function Inbox() {
  const [messages, setMessages] = useState(INBOX);
  const [removed, setRemoved] = useState(null);

  function handleDelete(id) {
    const message = messages.find((item) => item.id === id);
    if (!message) return;
    setRemoved(message);
    setMessages((list) => list.filter((item) => item.id !== id));
  }

  function undo() {
    if (!removed) return;
    setMessages((list) => [...list, removed].sort((a, b) =>
      INBOX.findIndex((item) => item.id === a.id) - INBOX.findIndex((item) => item.id === b.id)));
    setRemoved(null);
  }

  return (
    <>
    <ul className="inbox">
      {messages.map((message) => (
        <li key={message.id}>
          <div><strong>{message.from}</strong><span>{message.subject}</span></div>
          <button type="button" className="icon" aria-label={`Delete ${message.subject}`} onClick={() => handleDelete(message.id)}>🗑</button>
        </li>
      ))}
    </ul>
    {removed && <div><span role="status">Message deleted</span> <button type="button" onClick={undo}>Undo</button></div>}
    </>
  );
}
