import { useState } from 'react';
import { checkName, checkMobile, checkEmail } from './validate.js';

export default function SignUpForm() {
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState({});
  const [created, setCreated] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    const nextErrors = { name: checkName(name), mobile: checkMobile(mobile), email: checkEmail(email) };
    setErrors(nextErrors);
    if (Object.values(nextErrors).some(Boolean)) {
      setCreated('');
      return;
    }
    setCreated(`Account created for ${name.trim()}.`);
  }

  return (
    <form className="stack" onSubmit={handleSubmit} noValidate>
      <label htmlFor="signup-name">Full name</label>
      <input
        id="signup-name"
        className={errors.name ? 'invalid' : ''}
        aria-invalid={Boolean(errors.name)}
        aria-describedby={errors.name ? 'signup-name-error' : undefined}
        placeholder="Full name"
        value={name}
        onChange={(event) => setName(event.target.value)}
      />
      {errors.name && <p id="signup-name-error">{errors.name}</p>}
      <label htmlFor="signup-mobile">Mobile number</label>
      <input
        id="signup-mobile"
        type="tel"
        className={errors.mobile ? 'invalid' : ''}
        aria-invalid={Boolean(errors.mobile)}
        aria-describedby={errors.mobile ? 'signup-mobile-error' : undefined}
        placeholder="Mobile number"
        value={mobile}
        onChange={(event) => setMobile(event.target.value)}
      />
      {errors.mobile && <p id="signup-mobile-error">{errors.mobile}</p>}
      <label htmlFor="signup-email">Email</label>
      <input
        id="signup-email"
        type="email"
        className={errors.email ? 'invalid' : ''}
        aria-invalid={Boolean(errors.email)}
        aria-describedby={errors.email ? 'signup-email-error' : undefined}
        placeholder="Email"
        value={email}
        onChange={(event) => setEmail(event.target.value)}
      />
      {errors.email && <p id="signup-email-error">{errors.email}</p>}
      <button type="submit">Create account</button>
      <p className="result">{created}</p>
    </form>
  );
}
