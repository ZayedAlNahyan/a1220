import { useState } from 'react';
import { SLOTS } from './data.js';

export default function PickupTime() {
  const [time, setTime] = useState('');
  const [confirmed, setConfirmed] = useState('');

  return (
    <div className="stack">
      <fieldset>
        <legend>Pickup time</legend>
        {SLOTS.map((slot) => <label key={slot.time}>
          <input type="radio" name="pickup-time" value={slot.time}
            checked={time === slot.time} disabled={slot.left <= 0}
            onChange={() => setTime(slot.time)} />
          {`${slot.time}, ${slot.left > 0 ? `${slot.left} left` : 'full'}`}
        </label>)}
      </fieldset>
      <button type="button" disabled={!time} onClick={() => setConfirmed(`Pickup at ${time}.`)}>Confirm pickup</button>
      <p className="result">{confirmed}</p>
    </div>
  );
}
