import { useState } from 'react';
import { TICKET } from './data.js';

export default function TicketOffer() {
  const [protect, setProtect] = useState(false);
  const [offer, setOffer] = useState(true);
  const [charged, setCharged] = useState('');
  const shown = TICKET.price + (protect ? TICKET.protection : 0);
  const total = shown + TICKET.fee;

  return (
    <div className="stack">
      <p>{TICKET.name} · AED {TICKET.price}</p>
      {offer && (
        <div className="offer">
          <label>
            <input type="checkbox" checked={protect} onChange={(event) => setProtect(event.target.checked)} />
            {' '}Ticket protection · AED {TICKET.protection}
          </label>
          <button type="button" className="quiet" onClick={() => { setOffer(false); setProtect(false); }}>
            No thanks
          </button>
        </div>
      )}
      <p className="total">Total AED {total} (incl. AED {TICKET.fee} service fee)</p>
      <button type="button" onClick={() => setCharged(`Charged AED ${total}.`)}>Pay AED {total}</button>
      <p className="result">{charged}</p>
    </div>
  );
}
