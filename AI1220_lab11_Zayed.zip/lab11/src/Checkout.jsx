import { useRef, useState } from 'react';
import { ORDER } from './data.js';
import { placeOrder } from './api.js';

export default function Checkout() {
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState('');
  const inFlight = useRef(false);
  const total = ORDER.reduce((sum, line) => sum + line.price, 0);

  async function handleClick() {
    if (inFlight.current) return;
    inFlight.current = true;
    setPending(true);
    setMessage('');
    try {
      const answer = await placeOrder(ORDER);
      setMessage(`Order ${answer.id} placed, arrives at ${answer.eta}.`);
    } catch {
      setMessage('The order could not be placed. Please try again.');
    } finally {
      inFlight.current = false;
      setPending(false);
    }
  }

  return (
    <div className="stack">
      <ul className="lines">
        {ORDER.map((line) => (
          <li key={line.item}><span>{line.item}</span><span>AED {line.price}</span></li>
        ))}
        <li className="total"><span>Total</span><span>AED {total}</span></li>
      </ul>
      <button type="button" disabled={pending} onClick={handleClick}>
        {pending ? 'Placing order...' : 'Place order'}
      </button>
      <p role="status">{message}</p>
    </div>
  );
}
