# Team

| Name | GitHub username | Role |
| --- | --- | --- |
| Zayed | ZayedAlNahyan | Frontend and backend (solo) |

Zayed is working alone, as confirmed by the user. No partner is listed.

The reused implementation comes from `Alyrbi/a1220`; its original contributors and history remain attributed in the repository history and root README.
